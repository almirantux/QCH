package cl.itcoop.qch.base.modelo

class Articulo {
    data class Articulo(val titulo: String, val tema: String, val url: String )
}