package cl.itcoop.qch.base.modelo

 class Video {
       data class Video(val titulo: String, val tema: String, val enlace: String )
}