package cl.itcoop.qch.base.modelo

 class Receta {
       data class Receta(val nombre: String, val dificultad: String, val imagen: String )
}